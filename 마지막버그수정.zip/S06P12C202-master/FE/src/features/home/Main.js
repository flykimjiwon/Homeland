/* eslint-disable */
import React, { Component } from "react";
import "./Main.css";
import "aos/dist/aos.css";
import Home from "./Home";

function Main() {
  return <Home></Home>;
}

export default Main;
