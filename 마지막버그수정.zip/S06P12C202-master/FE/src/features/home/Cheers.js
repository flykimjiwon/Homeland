import { useEffect, useState } from 'react';
import './Cheers.css'
import IMG from './img/cheers.png'


function Cheers() {

  return (
<div className="zoom-in-out-box">
<div className='ch'>
<img src={IMG} width='200px'></img>
</div>
      </div>

  );
}

export default Cheers;