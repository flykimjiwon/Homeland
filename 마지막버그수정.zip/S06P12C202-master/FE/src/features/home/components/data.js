export default [
  {
    title : "First Update Note",
    date : "2022-01-01",
    content : "지금은 캐러셀 개발중"
  },
  {
    title : "Second Update Note",
    date : "2022-01-02",
    content : "넘어가면 이건 보이겠지"
  },
  {
    title : "Third Update Note",
    date : "2022-01-03",
    content : "세번째가 마지막인데 첫째로 돌아가나?"
  },
] 
