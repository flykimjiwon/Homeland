## Java Openjdk 11 버전 설치하기

```Bash
sudo apt-get update
sudo apt-get install openjdk-11-jdk -y
```



### 자바 버전 확인하기



![image-20220214150336025](https://raw.githubusercontent.com/rudy0103/save-image-repo/master/img/image-20220214150336025.png)

