## Gradle 설치 6.8.3

```bash
sudo apt-get update 
sapt-get install gradle
```

![image-20220214145156961](https://raw.githubusercontent.com/rudy0103/save-image-repo/master/img/image-20220214145156961.png)



-----------------------------

### gradle 버전이 안맞을 때

레포지토리 추가

```
sudo add-apt-repository ppa:cwchien/gradle
```

```bash
sudo apt-get update
sudo apt-get install gradle-6.8.3
```



![image-20220214145511469](https://raw.githubusercontent.com/rudy0103/save-image-repo/master/img/image-20220214145511469.png)

6.8.3 버전으로 설치 완료



