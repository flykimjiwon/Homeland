## MySql 설치

```
sudo apt-get update
sudo apt-get install mysql-server -y
```

![image-20220214160603528](https://raw.githubusercontent.com/rudy0103/save-image-repo/master/img/image-20220214160603528.png)



! 프로젝트에서

MySql 계정, 비밀번호, DB관련 설정 필수!

기본 포트 3306 그대로 사용

프로젝트 sql 설정 application.properties에서 확인할 수 있습니다.



