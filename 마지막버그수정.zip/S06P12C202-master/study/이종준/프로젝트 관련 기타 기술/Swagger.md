# Swagger

### Swagger란?

API Development Tool

Spring과 높은 호환성(Flask도 사용 가능)

삼성전자, 네이버, 카카오, NHN 등 대부분의 회사에서 사용



### Why Swagger?

백엔드 개발자와 프론트엔드 개발자의 소통 도구

개발자는 Interface로 소통한다!

Interface는 View에 의해 설계될 때가 많음.

API 정의, 공유, Test, 문서화에 적합한 도구

협업이나 원격 근무 환경에서 프로젝트 수행 가능

Interface 정의가 명확했다면 각자의 몫을 만들면 완성

(안되면? => 니 탓...)



**웬만하면 사용해보자!**