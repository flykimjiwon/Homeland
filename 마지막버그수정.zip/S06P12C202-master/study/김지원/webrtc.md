# WEBRTC 관련 js공부목록

기본은 순수 javascript로 진행

 https://developer.mozilla.org/ko/docs/Web/API/MediaDevices

참고!





playsinline : 브라우저 속성, 전체화면이 되지않고 웹사이트 안에서만 실행되게해줌

https://developer.mozilla.org/ko/docs/Web/API/MediaDevices/getUserMedia

async,await등 공부하기 그냥 싹공부

https://developer.mozilla.org/ko/docs/Learn/JavaScript/Asynchronous/Async_await

https://joshua1988.github.io/web-development/javascript/javascript-asynchronous-operation/

https://joshua1988.github.io/web-development/javascript/promise-for-beginners/

https://joshua1988.github.io/web-development/javascript/js-async-await/#%EB%93%A4%EC%96%B4%EA%B0%80%EB%A9%B0

https://joshua1988.github.io/web-development/fe-sangdamso-review/#%EC%95%9E%EC%9C%BC%EB%A1%9C%EB%8F%84-%EA%B3%84%EC%86%8D-%EC%9A%B4%EC%98%81%ED%95%98%EC%8B%A4-%EA%B1%B4%EA%B0%80%EC%9A%94

https://joshua1988.github.io/web-development/interview/frontend-questions/



